package hotpatching.animation;
import java.awt.*;

import javax.swing.*;

public class Trafficlight  {

    static Interpreter interpreter = new Interpreter();

	public static void main(String[] args) throws InterruptedException {

		JFrame frame = initializeFrame();

		Light l1 = new Light();

		frame.add(l1);
        
		SocketServer server = new SocketServer();
        server.setInterpreter(interpreter);
        server.start();
        
		/*while (true) {
			l1.incrementValue();

			Thread.sleep(500);

			l1.swapEm();

		}*/

	}

	private static JFrame initializeFrame() {
		JFrame frame = new JFrame();
		frame.setTitle("Trafficlight");
		frame.setSize(250, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		return frame;
	}

	static class Light extends JPanel implements TrafficCommandListener {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		private int iValue = 0;
		private int iDistance = 90;
		private int topLightHeight = 10;
		private Color iRed = Color.black;
		private Color iYellow = Color.black;
		private Color iGreen = Color.black;

		Light() {
	        interpreter.setCommandListener(this);
	        interpreter.start();
		}

		public void paintComponent(Graphics g) {
			defineLight(g);

		}

		public int getValue() {
			return this.iValue;
		}

		public void setLighDistance(int distance) {

			this.iDistance = distance;
		}

		public void incrementValue() {
			if (this.iValue == 25) {
				this.iValue = -1;
			}

			this.iValue = this.iValue + 1;
		}

		public void defineLight(Graphics g) {

			g.setColor(this.iRed);
			g.fillRoundRect(80, this.topLightHeight, 80, 80, 70, 70);

			g.setColor(this.iYellow);
			g.fillRoundRect(80, this.topLightHeight + this.iDistance, 80, 80, 70, 70);

			g.setColor(this.iGreen);
			g.fillRoundRect(80, this.topLightHeight + 2 * this.iDistance, 80, 80, 70, 70);

		}
		
		@Override
	    public void onChangeColor(String id, String color) {
			this.iYellow = Color.black;
			this.iRed = Color.black;
			this.iGreen = Color.black;

	        if(id.equals("top")) {
	        	this.iRed = Color.red;
	        } else if(id.equals("middle")) {
	        	this.iYellow = Color.yellow;
	        } else if(id.equals("bottom")) {
	        	this.iGreen = Color.green;
	        }
	        
	        repaint();
	    }

	}
}