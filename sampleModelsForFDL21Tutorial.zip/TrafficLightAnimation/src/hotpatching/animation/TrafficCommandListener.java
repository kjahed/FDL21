package hotpatching.animation;

/**
 * Created by kjahed on 5/1/17.
 */
public interface TrafficCommandListener {
    void onChangeColor(String id, String color);
}
